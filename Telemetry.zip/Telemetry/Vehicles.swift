//
//  Map.swift
//  Telemetry
//
//  Created by Agentum on 08.07.16.
//  Copyright © 2016 GBU. All rights reserved.
//

import UIKit

struct Vehicles {
    var array:[Vehicle] = []
    init(){
        
    }
}