//
//  AutoCollectionCell.swift
//  Telemetry
//
//  Created by IMAC  on 28.07.16.
//  Copyright © 2016 GBU. All rights reserved.
//

import UIKit

class AutoCollectionCell: UICollectionViewCell {

    @IBOutlet var group: UILabel!
    @IBOutlet var companyName: UILabel!
    @IBOutlet var modelName: UILabel!
    @IBOutlet var model: UILabel!
    @IBOutlet var lastUpdate: UILabel!
    @IBOutlet var registrationNumber: UILabel!
    
}
