//
//  MenuItem.swift
//  GBU
//
//  Created by Agentum on 01.06.16.
//  Copyright © 2016 IMAC . All rights reserved.
//

import UIKit

enum MenuItem: String {
    case Maps = "Maps"
    case Profile = "Profile"
    case Settings = "Settings"
    case Company = "Company"
    case Exit = "Exit"
    case Vehicles = "Vehicles"
}
