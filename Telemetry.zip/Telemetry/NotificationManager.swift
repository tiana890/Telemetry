//
//  NotificationManager.swift
//  GBU
//
//  Created by Agentum on 01.06.16.
//  Copyright © 2016 IMAC . All rights reserved.
//

import UIKit

struct NotificationManager{
    static var MenuItemSelectedNotification = "MenuItemSelectedNotification"
    static var AppAccountChangedNotification = "AppAccountChangedNotification"
}
