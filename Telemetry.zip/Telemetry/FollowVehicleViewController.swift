//
//  FollowVehicleViewController.swift
//  Telemetry
//
//  Created by IMAC  on 11.08.16.
//  Copyright © 2016 GBU. All rights reserved.
//

import UIKit

class FollowVehicleViewController: UIViewController {

}
