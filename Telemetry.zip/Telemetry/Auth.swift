//
//  Auth.swift
//  Telemetry
//
//  Created by Agentum on 13.07.16.
//  Copyright © 2016 GBU. All rights reserved.
//

import UIKit

struct Auth{
    var token: String?
    var reason: String?
}
