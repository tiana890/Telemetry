//
//  CompanyCollectionCell.swift
//  Telemetry
//
//  Created by IMAC  on 28.07.16.
//  Copyright © 2016 GBU. All rights reserved.
//

import UIKit

class CompanyTableCell: UITableViewCell {

    @IBOutlet var name: UILabel!
}
