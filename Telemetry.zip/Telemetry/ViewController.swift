//
//  ViewController.swift
//  Telemetry
//
//  Created by Agentum on 06.07.16.
//  Copyright © 2016 GBU. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

//    override func viewDidLoad() {
//        super.viewDidLoad()
//        self.view.backgroundColor = UIColor.blueColor()
//        // Do any additional setup after loading the view, typically from a nib.
//        if let v = NSBundle.mainBundle().loadNibNamed("MarkerIcon", owner: self, options: nil)[0] as? MarkerIcon{
//            v.center = self.view.center
//            markerView.carImage.transform = CGAffineTransformMakeRotation(90.0)
//            markerView.registrationNumber.text = [NSString stringWithFormat:@"%ld" ,(long)item.azimut.integerValue]
//            marker.iconView = markerView;
//
//            self.view.addSubview(v)
//        }
//        
//    }
//
//    override func didReceiveMemoryWarning() {
//        super.didReceiveMemoryWarning()
//        // Dispose of any resources that can be recreated.
//    }


}

